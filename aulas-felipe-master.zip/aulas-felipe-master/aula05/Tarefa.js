class Tarefa {
  constructor(id, descricao, categoria, feito) {
    this.id = id;
    this.descricao = descricao;
    this.categoria = categoria;
    this.feito = feito;
  }
}
