/**
 * - Revisando filter, map e reduce
 * - Começando a falar sobre promises
 * - Começando a falar sobre http
 * - Criando uma listagem com dados que vem do servidor
 */