# Projeto 1

Projeto de interação com usuário usando js.

Simula um carrinho de compras.
